#
# Use this file to create theh database for the NagiosGrapher Hook NG2MySQL.pm
#
# Usage:  $ mysql -u root -p < ng2mysql_create_db.sql
#

DROP DATABASE IF EXISTS `nagiosgrapher`;

CREATE DATABASE `nagiosgrapher`;


USE `nagiosgrapher`;


DROP TABLE IF EXISTS `servicevalues`;

CREATE TABLE `servicevalues` (
	`timestamp`	timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
	`host`		varchar(255) collate latin1_general_cs default NULL,
	`service`	varchar(255) collate latin1_general_cs default NULL,
	`label`		varchar(255) collate latin1_general_cs default NULL,
	`value`		float default NULL #,
	# do not forget to uncomment the comma above upon uncommenting the line below
	# KEY `timestamp_host_service_label` (`timestamp`,`host`,`service`,`label`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;


# If indexes have not already been created via the KEY directive in CREATE TABLE,
# uncomment the following line upon performance problems
# CREATE INDEX `timestamp_host_service_label` on `servicevalues` (`timestamp`,`host`,`service`,`label`);

# Please set username and password
GRANT SELECT,INSERT ON `nagiosgrapher`.* TO `nguser`@`localhost` IDENTIFIED BY 'ngpasswd';

FLUSH PRIVILEGES;

