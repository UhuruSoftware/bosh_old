#!/usr/bin/perl

use IO::Socket::INET;

my ($text) = @ARGV;

$MySocket=new IO::Socket::INET->new(PeerPort=>5667, Proto=>'udp', PeerAddr=>'localhost');
$MySocket->send($text);
$MySocket->close();

