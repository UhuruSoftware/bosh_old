package NagiosGrapher::Hooks::SrvExtTest;

use NagiosGrapher::Hooks::Generic;
@ISA = ("NagiosGrapher::Hooks::Generic");


1;