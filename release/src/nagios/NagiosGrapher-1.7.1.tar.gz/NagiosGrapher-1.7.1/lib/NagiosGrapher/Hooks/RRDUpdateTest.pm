package NagiosGrapher::Hooks::RRDUpdateTest;

use NagiosGrapher::Hooks::Generic;

use vars qw (
	@ISA
);

@ISA = ('NagiosGrapher::Hooks::Generic');

sub init {
	$self = shift;

	$self->SetTypes (
		'before_rrdupdate',
	);

	return $self->SUPER::init(@_);
}

sub prepare {
	my $self = shift;
	use Data::Dumper;

	$self->print_log("Service: ". $self->Service);

	return 1;
}

sub commit {
	my $self = shift;
	my $values = $self->Values;

	foreach (keys %{ $self->{Values} }) {
		#if ($_ =~ m/user/i) {
		#	$self->{Values}->{$_} = 10;
		#}
	}

	return 1;
}

sub cleanup {
	my $self = shift;
	$self->print_log('clean up ...');

	return 1;
}

1;