package NagiosGrapher::Hooks::ImageGraphTest;
use NagiosGrapher::Hooks::Generic;

use vars qw (
	@ISA
);

@ISA = ('NagiosGrapher::Hooks::Generic');

sub init {
	$self = shift;

	$self->SetTypes (
		'before_imagegraph',
		'before_imagemultigraph'
	);

	return $self->SUPER::init(@_);
}

sub prepare {
	my $self = shift;

	my $values = $self->Values;

	if ($values->{'params'}->{'only-graph'} eq 'true') {
		return;
	}
	else {
		return 1;
	}
}

sub commit {
	my $self = shift;
	my $values = $self->Values;

	# use Data::Dumper;
	# $self->print_log(
	# 	Dumper($values)
	# );

	$values->{vertical} .= ' Mod1 is running ...';

	return 1;
}

sub cleanup {
	my $self = shift;
	return 1;
}

1;